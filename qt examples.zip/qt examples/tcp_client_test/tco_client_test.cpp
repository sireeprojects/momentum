#include "tco_client_test.h"
#include "ui_tco_client_test.h"

tco_client_test::tco_client_test(QWidget *parent) : QMainWindow(parent), ui(new Ui::tco_client_test) {
    ui->setupUi(this);
    value = 0;
    ui->status->setText("Disconnected");
    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(readyRead()),this, SLOT(readyRead()));
}

tco_client_test::~tco_client_test() {
    delete ui;
}

void tco_client_test::on_pushButton_clicked() {
    qApp->exit();
}

// connect
void tco_client_test::on_pushButton_2_clicked() {
    socket->connectToHost("hsv-avip04",8888);
    if(socket->waitForConnected(1000)) {
         ui->status->setText("Connected");
    } else {
         ui->status->setText("Connection Error");
    }
}



// send
void tco_client_test::on_send_data_clicked() {
//    char d[64];
//    memset(d,0,64);
//    memcpy(d,ui->lineEdit->text().toStdString().c_str(), 64);
//    socket->write(ui->lineEdit->text().toStdString().c_str(), 64);
//    socket->waitForBytesWritten();
//    value = ui->lineEdit->text().toInt();
//    value++;
//    ui->lineEdit->setText(QString("%1").arg(value));
    ctlcmd cmd;
    cmd.portno = 1;
    cmd.cmd = START;
    socket->write((char*)&cmd,64);
    socket->waitForBytesWritten();
}

void tco_client_test::on_disconnect_clicked() {
    socket->disconnectFromHost();
    if(socket->state() == QAbstractSocket::UnconnectedState
            || socket->waitForDisconnected(1000)) {
         ui->status->setText("Disconnected");
    } else {
         ui->status->setText("Disconnect Error");
    }
}

void tco_client_test::readyRead() {
    ui->stats->setText(QString(socket->readAll()));
    // readll should be replaced by read 4 bytes at a time
    // since there is no message boundary in tcp
}
