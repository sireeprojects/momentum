#ifndef TCO_CLIENT_TEST_H
#define TCO_CLIENT_TEST_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class tco_client_test;
}

typedef enum {
    START,
    STOP,
    CLEAR_STATS
} ctl_commands;


#pragma pack(push,1)
struct ctlcmd {
    uint32_t portno : 32;
    ctl_commands cmd : 32;
    char pad[56];
};
#pragma pack(pop)

class tco_client_test : public QMainWindow
{
    Q_OBJECT

public:
    explicit tco_client_test(QWidget *parent = 0);
    ~tco_client_test();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_send_data_clicked();
    void on_disconnect_clicked();

public slots:
    // void connected();
    // void disconnected();
    // void bytesWritten(qint64 bytes);
    void readyRead();

private:
    Ui::tco_client_test *ui;
    QTcpSocket *socket;
    int value;
};

#endif // TCO_CLIENT_TEST_H
