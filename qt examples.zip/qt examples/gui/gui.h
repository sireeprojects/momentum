#ifndef GUI_H
#define GUI_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QString>
#include <QDebug>
#include <QTableWidgetItem>
#include <QThread>
#include <QMetaType>

namespace Ui {
class gui;
}

typedef enum {
    START,
    STOP,
    CLEAR_STATS
} command;

typedef enum {
    PORT_INFO,
    PORT_STATS,
    COMMAND
} metadata_type;

#pragma pack(push,1)
struct port_info {
    char port_name[32];
    uint32_t port_num : 32;
    char pad[24];
};
#pragma pack(pop)

#pragma pack(push,1)
struct port_stats {
    uint32_t port_num : 32;
    uint64_t transmitted : 64;
    uint64_t received : 64;
    char pad[40];
};
#pragma pack(pop)

#pragma pack(push,1)
struct port_cmds {
    uint32_t port_num : 32;
    uint32_t transmitted : 32;
    char pad[52];
};
#pragma pack(pop)

#pragma pack(push,1)
struct metadata {
    metadata_type type : 8;
    union {
        port_info info;
        port_stats stats;
        port_cmds cmd;
    };
};
#pragma pack(pop)

Q_DECLARE_METATYPE(metadata)

////////////////////////////////////////////////////////////////

class show_stats : public QThread
{
    Q_OBJECT
public:
    explicit show_stats();
    void run();
    QTcpSocket *socket;
    void do_connect();
    void do_disconnect();
signals:
    void data_available(metadata m);
public slots:
    void initSocket();
};

////////////////////////////////////////////////////////////////

class gui : public QMainWindow
{
    Q_OBJECT

public:
    explicit gui(QWidget *parent = 0);
    ~gui();

private slots:
    void on_btnQuit_clicked();
    void on_btnBuild_clicked();
    void on_btnConnect_clicked();
    void on_btnDisconnect_clicked();
    void on_btnStop_clicked();

private:
    Ui::gui *ui;
    int nof_ports;
    // QTcpSocket *socket;
    // QString serverName;
    // int serverPort;
    uint32_t port_idx;
    show_stats *metrics;

public slots:
    void process_data(metadata meta);

signals:
    void initSocket();
};






#endif // GUI_H
