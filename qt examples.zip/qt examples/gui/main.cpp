#include "gui.h"
#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    // a.setStyle("Fusion");
    qRegisterMetaType<metadata>("metadata");
    gui w;
    w.show();
    return a.exec();
}
