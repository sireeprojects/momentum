#include "gui.h"
#include "ui_gui.h"

gui::gui(QWidget *parent) : QMainWindow(parent), ui(new Ui::gui) {
    ui->setupUi(this);
    nof_ports = 8;
    ui->stats->setColumnWidth(0,100);
    ui->stats->setColumnWidth(1,120);
    ui->stats->setColumnWidth(2,200);
    ui->stats->setColumnWidth(3,200);
    ui->statusBar->showMessage("Not Connected");

    metrics = new show_stats();
    connect(metrics, SIGNAL(data_available(metadata)),this, SLOT(process_data(metadata)));
    connect(this, SIGNAL(initSocket()), metrics, SLOT(initSocket()));
    port_idx = 0;
}


gui::~gui() {
    delete ui;
}


void gui::on_btnQuit_clicked() {
    QApplication::quit();
}


void gui::on_btnBuild_clicked() {
}


void gui::on_btnConnect_clicked() {
    emit initSocket();
}


void gui::on_btnDisconnect_clicked() {
    qDebug() << "Disconnected";
    metrics->do_disconnect();
}


void show_stats::do_connect() {
    socket = new QTcpSocket();
    qDebug() << "Creating sockets in thread";
    socket->connectToHost("hsv-avip04", 8889);
    if(socket->waitForConnected(1000)) {
        qDebug() << "Connected";
    } else {
         qDebug() << "Connection Error";
    }
}


void show_stats::do_disconnect() {
    socket->close();
//    socket->disconnectFromHost();
}


void show_stats::initSocket() {
    start();
}


void show_stats::run() {
    do_connect();
    metadata meta;
    while(true) {
        if (socket->bytesAvailable() < 64) {
            socket->waitForReadyRead();
        } else {
            socket->read((char*)&meta,64);
            emit data_available(meta);
        }
    }
}


void gui::process_data(metadata meta) {
    switch (meta.type) {
        case PORT_INFO: {
            ui->stats->insertRow(ui->stats->rowCount());
            ui->stats->setRowHeight(port_idx,34);
            QTableWidgetItem* itemName = new QTableWidgetItem;
            itemName->setText(meta.info.port_name);
            ui->stats->setItem(port_idx,0,itemName);
            QTableWidgetItem* itemId = new QTableWidgetItem;
            itemId->setText(QString("%1").arg(meta.info.port_num));
            ui->stats->setItem(port_idx,1,itemId);
            port_idx++;
            break;
            }
        case PORT_STATS: {
            QTableWidgetItem *pCell = ui->stats->item(meta.stats.port_num,2);
            if(!pCell) {
                pCell = new QTableWidgetItem;
                pCell->setText(QString("%1").arg(meta.stats.transmitted));
                ui->stats->setItem(meta.stats.port_num,2, pCell);
            } else {
                ui->stats->item(meta.stats.port_num,2)->setText(QString("%1").arg(meta.stats.transmitted));
            }
            break;
        }
        case COMMAND: {
            break;
        }
        default: {
            qDebug() << "Unidentified metadata" ;
            break;
        }
    }
}


void gui::on_btnStop_clicked() {
    metrics->terminate();
}


show_stats::show_stats() {
}
