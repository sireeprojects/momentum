#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H


typedef enum {
    START,
    STOP,
    CLEAR_STATS
} command;


typedef enum {
    PORT_INFO,
    PORT_STATS,
    COMMAND,
    PORT_TIME
} metadata_type;


#pragma pack(push,1)
struct port_info {
    char port_name[32];
    uint32_t port_num : 32;
    char pad[24];
};
#pragma pack(pop)


#pragma pack(push,1)
struct port_stats {
    uint32_t port_num : 32;
    uint64_t transmitted : 64;
    uint64_t received : 64;
    char pad[40];
};
#pragma pack(pop)


#pragma pack(push,1)
struct port_cmds {
    uint32_t port_num : 32;
    command cmd : 32;
    char pad[52];
};
#pragma pack(pop)


#pragma pack(push,1)
struct port_time {
    uint32_t port_num : 32;
    uint64_t transmitted : 64;
    uint64_t received : 64;
    char pad[40];
};
#pragma pack(pop)


#pragma pack(push,1)
struct metadata {
    metadata_type type : 32;
    union {
        port_info info;
        port_stats stats;
        port_cmds cmd;
        port_time time;
    };
};
#pragma pack(pop)


Q_DECLARE_METATYPE(metadata)


#endif // DATA_STRUCTURES_H
