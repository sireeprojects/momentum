#ifndef GENESISGUI_H
#define GENESISGUI_H

#include <QMainWindow>
#include <QString>
#include <QTableWidgetItem>
#include "data_structures.h"
#include "sock_thread.h"

QT_BEGIN_NAMESPACE
namespace Ui { class genesisGui; }
QT_END_NAMESPACE

class genesisGui : public QMainWindow
{
    Q_OBJECT

public:
    genesisGui(QWidget *parent = nullptr);
    ~genesisGui();

private slots:
    void on_btnQuit_clicked();
    void on_btnDisconnect_clicked();
    void on_btnStop_clicked();
    void on_btnConnect_clicked();
    void on_btnStart_clicked();

    void on_btnClear_clicked();

private:
    Ui::genesisGui *ui;
    sock_thread *socket;
    quint32 msg_cntr;
    quint32 port_index;

signals:
    void do_connect(QString hostName, quint32 port);
    void do_start();
    void do_stop();
    void do_disconnect();

public slots:
    void update_table(metadata meta);
    void add_status_msg(QString msg);
    void disconnect_done();
};
#endif // GENESISGUI_H
