#include "genesisgui.h"
#include "ui_genesisgui.h"


genesisGui::genesisGui(QWidget *parent) : QMainWindow(parent), ui(new Ui::genesisGui)
{
    ui->setupUi(this);
    ui->tw->setColumnWidth(0,75);
    ui->tw->setColumnWidth(1,50);
    ui->tw->setColumnWidth(2,150);
    ui->tw->setColumnWidth(3,150);
    ui->tw->setColumnWidth(4,150);
    ui->tw->setColumnWidth(5,150);

    // defaults
    msg_cntr = 0;
    port_index = 0;
    ui->btnDisconnect->setEnabled(false);
    ui->btnStart->setEnabled(false);
    ui->btnStop->setEnabled(false);
    ui->serverName->setFixedHeight(35);
    ui->serverName->setText("hsv-avip04");
    ui->serverName->setFixedWidth(150);
    ui->serverPort->setFixedHeight(35);
    ui->serverPort->setFixedWidth(100);
    ui->serverPort->setText("8889");

    // create socket thread
    socket = new sock_thread(this);

    // signal and slot connections
    connect(this, SIGNAL(do_connect(QString,quint32)), socket, SLOT(do_connect(QString,quint32)));
    connect(this, SIGNAL(do_disconnect()), socket, SLOT(do_disconnect()));
    connect(this, SIGNAL(do_start()), socket, SLOT(do_start()));
    connect(this, SIGNAL(do_stop()), socket, SLOT(do_stop()));
    connect(socket, SIGNAL(add_status_msg(QString)), this, SLOT(add_status_msg(QString)));
    connect(socket, SIGNAL(update_table(metadata)), this, SLOT(update_table(metadata)));
    connect(socket, SIGNAL(disconnect_done()), this, SLOT(disconnect_done()));
}


void genesisGui::on_btnConnect_clicked()
{
    QString host = ui->serverName->text();
    quint32 port = ui->serverPort->text().toUInt();
    emit do_connect(host, port);
    ui->btnConnect->setEnabled(false);
    ui->btnDisconnect->setEnabled(true);
    ui->btnStart->setEnabled(true);
}


void genesisGui::on_btnDisconnect_clicked()
{
    emit do_disconnect();
    ui->btnConnect->setEnabled(true);
    ui->btnDisconnect->setEnabled(false);
    ui->btnStart->setEnabled(false);
    ui->btnStop->setEnabled(false);
}


void genesisGui::on_btnStart_clicked()
{
    emit do_start();
    ui->btnStart->setEnabled(false);
    ui->btnStop->setEnabled(true);
}


void genesisGui::on_btnStop_clicked()
{
    emit do_stop();
    ui->btnStart->setEnabled(true);
    ui->btnStop->setEnabled(false);
}


void genesisGui::update_table(metadata meta)
{
    switch (meta.type) {
        case PORT_INFO: {
            ui->tw->insertRow(ui->tw->rowCount());
            ui->tw->setRowHeight(port_index,30);
            QTableWidgetItem* itemName = new QTableWidgetItem;
            itemName->setText(meta.info.port_name);
            ui->tw->setItem(port_index,0,itemName);
            QTableWidgetItem* itemId = new QTableWidgetItem;
            itemId->setText(QString("%1").arg(meta.info.port_num));
            ui->tw->setItem(port_index,1,itemId);
            port_index++;
            break;
            }
        case PORT_STATS: {
            QTableWidgetItem *pCell = ui->tw->item(meta.stats.port_num,2);
            if(!pCell) {
                pCell = new QTableWidgetItem;
                pCell->setText(QString("%1").arg(meta.stats.transmitted));
                ui->tw->setItem(meta.stats.port_num,2, pCell);
            } else {
                ui->tw->item(meta.stats.port_num,2)->setText(QString("%1").arg(meta.stats.transmitted));
            }
            break;
        }
        //case PORT_TIME: {
        //    QTableWidgetItem *pCell = ui->tw->item(meta.time.port_num,3);
        //    if(!pCell) {
        //        pCell = new QTableWidgetItem;
        //        pCell->setText(QString("%1 secs").arg(meta.time.transmitted));
        //        ui->tw->setItem(meta.time.port_num,3, pCell);
        //    } else {
        //        ui->tw->item(meta.time.port_num,3)->setText(QString("%1 secs").arg(meta.time.transmitted));
        //    }
        //    break;
        //}
        case PORT_TIME: {
            QTableWidgetItem *pCell = ui->tw->item(meta.time.port_num,3);
            if(!pCell) {
                pCell = new QTableWidgetItem;
                uint64_t tx = ui->tw->item(meta.time.port_num,2)->text().toUInt();
                pCell->setText(QString("%1").arg(tx/meta.time.transmitted));
                ui->tw->setItem(meta.time.port_num,3, pCell);
            } else {
                uint64_t tx = ui->tw->item(meta.time.port_num,2)->text().toUInt();
                ui->tw->item(meta.time.port_num,3)->setText(QString("%1").arg(tx/meta.time.transmitted));
            }
            break;
        }
        case COMMAND: {
            add_status_msg("Command processing not yet implemented");
            break;
        }
        default: {
            add_status_msg("Unidentified metadata");
            break;
        }
    }
}


void genesisGui::add_status_msg(QString msg)
{
    QString s = QString("(%1) %2").arg(msg_cntr).arg(msg);
    ui->msgs->addItem(s);
    ui->msgs->scrollToBottom();
    msg_cntr++;
}


void genesisGui::disconnect_done()
{
    ui->tw->setRowCount(0);
    port_index = 0;
}


void genesisGui::on_btnQuit_clicked()
{
    QApplication::quit();
}


genesisGui::~genesisGui()
{
    delete ui;
}


void genesisGui::on_btnClear_clicked()
{
    ui->msgs->clear();
}
