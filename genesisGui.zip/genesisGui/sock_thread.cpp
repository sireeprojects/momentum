#include "sock_thread.h"


sock_thread::sock_thread(QObject *parent) : QThread(parent)
{
    stop_thread = true;
}


void sock_thread::do_connect(QString hostName, quint32 port) {
    stop_thread = false;
    serverName = hostName;
    serverPort = port;
    start();
}


void sock_thread::init_sockets()
{
    socket = new QTcpSocket();
    connect(socket, SIGNAL(disconnected()), this, SLOT(do_disconnected()));
    emit add_status_msg("Connecting to server...");
    socket->connectToHost(serverName, serverPort);
    if(socket->waitForConnected(1000)) {
        emit add_status_msg("Successfully connected to server");
    } else {
         emit add_status_msg("Connected error");
    }
}


QString sock_thread::to_str(metadata m)
{
    QString str;
    if (m.type == COMMAND) {
        switch (m.cmd.cmd) {
            case START: str = "START"; break;
            case STOP: str = "STOP"; break;
            case CLEAR_STATS: str = "CLEAR"; break;
        }
        return str;
    } else {
        return "";
    }
}


void sock_thread::run()
{
    init_sockets();

    metadata meta;
    while(!stop_thread) {
        if (msgq.empty()) {
            if (socket->bytesAvailable() < 64) {
                socket->waitForReadyRead(500);
            } else {
                socket->read((char*)&meta,64);
                emit update_table(meta);
            }
        } else {
            metadata meta = msgq.dequeue();
            socket->write((char*)&meta, 64);
            socket->waitForBytesWritten();
            emit add_status_msg(
                QString("%1 Command sent to server").arg(to_str(meta)));
        }
    }
    emit add_status_msg("Socket thread stopped");
}


void sock_thread::do_start()
{
    metadata meta;
    meta.type = COMMAND;
    meta.cmd.cmd = START;
    msgq.enqueue(meta);
}


void sock_thread::do_stop()
{
    metadata meta;
    meta.type = COMMAND;
    meta.cmd.cmd = STOP;
    msgq.enqueue(meta);
}

void sock_thread::do_disconnect()
{
    stop_thread = true;
    terminate();
    QThread::msleep(100);
    socket->disconnectFromHost();
    emit add_status_msg("Disconnected from server");
    emit disconnect_done();
}

void sock_thread::do_disconnected()
{
    stop_thread = true;
    terminate();
    emit add_status_msg("Server disconnected");
}


