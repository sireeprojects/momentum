#ifndef SOCK_THREAD_H
#define SOCK_THREAD_H

#include <QThread>
#include <QTcpSocket>
#include <QHostAddress>
#include <QString>
#include <QQueue>
#include "data_structures.h"

class sock_thread : public QThread
{
    Q_OBJECT
public:
    explicit sock_thread(QObject *parent = nullptr);
    QTcpSocket *socket;

    void run();

public slots:
    void do_connect(QString hostName, quint32 port);
    void do_start();
    void do_stop();
    void do_disconnect();
    void do_disconnected();

signals:
    void update_table(metadata meta);
    void add_status_msg(QString msg);
    void disconnect_done();

private:
    bool stop_thread;
    void init_sockets();
    QQueue<metadata> msgq;
    QString to_str(metadata m);
    QString serverName;
    quint32 serverPort;
};

#endif // SOCK_THREAD_H
