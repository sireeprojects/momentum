#include "genesisgui.h"
#include <QApplication>
#include "data_structures.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    qRegisterMetaType<metadata>("metadata");
    genesisGui w;
    w.show();
    return a.exec();
}
